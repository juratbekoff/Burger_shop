import { nanoid } from 'nanoid'

console.log(1, nanoid(5))
console.log(2, nanoid(10))
console.log(3, nanoid(1))
console.log(4, nanoid(9))
console.log(5, nanoid(100))
console.log(6, nanoid(41))