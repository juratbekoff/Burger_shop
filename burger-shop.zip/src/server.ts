import express from 'express'
import { engine } from 'express-handlebars'
import { nanoid } from 'nanoid'
import path from 'path'
import { burgers } from './burger.storage'
import { cart, Item } from './cart.storage'

// express config
const app = express()
app.use(express.json())
app.use(express.urlencoded( { extended: true } ))
app.use(express.static(path.join(__dirname, "../public")))

// handlebars
app.engine('.hbs', engine( { extname: '.hbs' } ))
app.set('view engine', '.hbs')
app.set('views', './pages')

// Routes
app.get('/', (req, res) => {
  res.render('index', { burgers, cart })
})

app.get('/confirm', (req, res) => {
  res.render('confirm')
})
// URL param
app.get('/buy/:id', (req, res) => {

  let burger = burgers.find(b => b.id == req.params.id)!
  
  let item: Item = { 
      id: nanoid(),
      name: burger.name,
      price: burger.price
  }

  cart.items.push(item)
  cart.total += burger.price

  res.redirect('/')
})

app.get('/remove/:id', (req, res) => {
  let i = cart.items.findIndex(item => item.id === req.params.id)
  cart.total -= cart.items[i].price
  cart.items.splice(i, 1)

  res.redirect('/')
})

app.listen(8080, () => console.log("Server is running on http://localhost:8080"))