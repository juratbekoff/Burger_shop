export type Item = {
  id: string,
  name: string,
  price: number
}

export type Cart = {
  total: number,
  items: Item[]
}

export const cart: Cart = {
  total: 0,
  items: []
}